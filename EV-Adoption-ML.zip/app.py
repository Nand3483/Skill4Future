"""
Project: EV-Adoption-ML
Author: Darshan Gohel
Shared for academic group work only.
"""



import streamlit as st
import pandas as pd
import joblib

model = joblib.load("ev_model.pkl")
scaler = joblib.load("ev_scaler.pkl")

st.title("🚗 Global EV Sales Forecast (Millions)")

Year = st.number_input("Year", step=1)
Market_Share = st.number_input("Market Share (%)")
YoY_Growth = st.number_input("YoY Growth (%)")
Battery_Price = st.number_input("Battery Price (USD/kWh)")
Policy_Index = st.number_input("Policy Incentive Index")
Infra_Score = st.number_input("Infrastructure Score")
Oil_Price = st.number_input("Oil Price (USD)")
CO2_Index = st.number_input("CO2 Regulation Index")
Avg_Range = st.number_input("Average EV Range (km)")

if st.button("Predict EV Sales"):
    df = pd.DataFrame([[Year, Market_Share, YoY_Growth, Battery_Price,
                        Policy_Index, Infra_Score, Oil_Price,
                        CO2_Index, Avg_Range]],
        columns=['Year','Market_Share_Pct','YoY_Growth_Pct',
                 'Battery_Price_USD_kWh','Policy_Incentive_Index',
                 'Infra_Score','Oil_Price_USD',
                 'CO2_Regulation_Index','Avg_Range_km'])

    df_scaled = scaler.transform(df)
    result = model.predict(df_scaled)

    st.success(f"Predicted EV Sales: {result[0]:.2f} Million Units")
